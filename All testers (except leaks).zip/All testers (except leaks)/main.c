/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: limartin <limartin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/08 19:00:41 by limartin          #+#    #+#             */
/*   Updated: 2020/01/24 20:46:31 by limartin      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include "get_next_line.h"
//#include "get_next_line_bonus.h"

#ifndef BUFFER_SIZE
//# define BUFFER_SIZE 1
// # define BUFFER_SIZE 3
//# define BUFFER_SIZE 4
// # define BUFFER_SIZE 5
//# define BUFFER_SIZE 25
//# define BUFFER_SIZE 1000000
//# define BUFFER_SIZE 2000000
//# define BUFFER_SIZE 3000000
//# define BUFFER_SIZE 4000000
//# define BUFFER_SIZE 5000000
//# define BUFFER_SIZE 6000000
//# define BUFFER_SIZE 7000000
//# define BUFFER_SIZE 8000000
//# define BUFFER_SIZE 8100000
//# define BUFFER_SIZE 8200000
//# define BUFFER_SIZE 8300000
//# define BUFFER_SIZE 8350000
//# define BUFFER_SIZE 8375000
//# define BUFFER_SIZE 8380000
//# define BUFFER_SIZE 8384000
//# define BUFFER_SIZE 8384050
//# define BUFFER_SIZE 8384055

//# define BUFFER_SIZE 8384056
//# define BUFFER_SIZE 8384060
//# define BUFFER_SIZE 8384070
//# define BUFFER_SIZE 8384071
//# define BUFFER_SIZE 8384072
//# define BUFFER_SIZE 8384119

//# define BUFFER_SIZE 8384120
//# define BUFFER_SIZE 8384150
//# define BUFFER_SIZE 8384200
//# define BUFFER_SIZE 8384278
//# define BUFFER_SIZE 8384279
//# define BUFFER_SIZE 1000000000
# define BUFFER_SIZE 2147483646

#endif

//#define BUFFER_SIZE 1000000000

//gcc -o test -Wall -Wextra -Werror main.c get_next_line.c get_next_line_utils.c -D BUFFER_SIZE=32 && ./test

//gcc -o test -Wall -Wextra -Werror main.c get_next_line_bonus.c get_next_line_utils_bonus.c -D BUFFER_SIZE=32 && ./test

int	get_next_line(int fd, char **line);

int		main(void)
{

//Declarations
	int		fd;
	int		red;
//	char	buf[BUFFER_SIZE + 1];
	char	*line;
//	char	**ptr;
write(1, "No segfault yet\n", 16);

//Opening a file
	fd = open("./bill.txt", O_RDONLY);
	fd = open("./simple.txt", O_RDONLY);
	// fd = open("./multi.txt", O_RDONLY);
	// fd = open("./4x4.txt", O_RDONLY);
	// fd = open("./4x4o.txt", O_RDONLY);
	// fd = open("./empty.txt", O_RDONLY);
	// fd = open("./almostempty.txt", O_RDONLY);
	// fd = open("./lone.txt", O_RDONLY);
	// fd = open("./bastard.txt", O_RDONLY);
	// fd = open("./long_line.txt", O_RDONLY);
	//fd = open("./jim.txt", O_RDONLY);
	// fd = open("./bibble.txt", O_RDONLY);
//	fd = open("./bill2.txt", O_RDONLY);
//	fd = 42;
	// fd = 1028; //supposed to break
	// fd = 0; //test with Ctrl D too
	//fd = 1;
	// fd = 2;
	
	if (fd == -1)
	{
		printf("Failed to open\n");
//		return (1);
	}
	if (fd != -1)
	{
		printf("Opened the file with file descriptor of %d\n", fd);
	}

//Reading & printing from opened file (standard)
/*	if (0)
	{
		red = 1;
		while (red)
		{
//		red = read(fd, buf, BUFFER_SIZE);
//		buf[BUFFER_SIZE] = '\0';
		int		len;
		len = strlen(buf);
		printf("%s|(%d)|", buf, len);
		printf("%s| BUFFER |\n", buf);
		bzero(buf, BUFFER_SIZE);
		}
	}
*/

//Reading & printing from opened file (GNL)
	if (0)
	{
		int b = 0;
		int i = 1;
		if (b)
		{
			while (i > 0)
			{
			b = get_next_line(fd, &line);
			//b = get_next_line(fd, ptr);
			i--;
			printf("%d| |%s|\n", b, line);
			//printf("\n");
			}
		}

			int a = 1;
			int c = 0;
		if (a)
		{
			while (a && a != -1)
			{
			a = (get_next_line(fd, &line));
			c = a + c;
			//printf("%d| |%s|\n", a, line); //return val
			printf("%d| |%s|\n", c, line); //line count
			free (line);
			}
		}
//		while (1)
//		{
//		}
		
	}

//Bonus

	if (0)
	{
		int a = 1;
	
		if (a)
		{
			int fd1 = open("./bill.txt", O_RDONLY);
			int fd2 = open("./simple.txt", O_RDONLY);
///			int fd3 = open("./multi.txt", O_RDONLY);
//			int fd4 = open("./4x4.txt", O_RDONLY);
//			int fd5 = open("./4x4o.txt", O_RDONLY);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd1, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

			a = (get_next_line(fd2, &line));
			printf("%d| |%s|\n", a, line); //return val
			free (line);

		}

	}

	if (1)
	{
			int alter;
			
			int fd1 = open("./bill2.txt", O_RDONLY);
			int fd2 = open("./bibble.txt", O_RDONLY);
			int a = 1;
			int c = 0;
			int d = 0;

			alter = 0;
			while (a && a != -1)
			{
				if (alter == 0)
				{
					fd = fd1;
					alter = 1;
				}
				else if (alter == 1)
				{
					fd = fd2;
					alter = 0;
				}
				a = (get_next_line(fd, &line));
				if (alter == 1) //bill2
				{
					c = a + c;
					printf("%d| |%s|\n", c, line); //line count
				}
				if (alter == 0) //bibble
				{
					d = a + d;
					printf("%d| |%s|\n", d, line); //line count
				}
				free (line);
			}
	}
		
	return (0);
}
